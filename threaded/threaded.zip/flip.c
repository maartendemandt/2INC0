/* 
 * Operating Systems [2INCO] Practical Assignment
 * Threaded Application
 *
 * STUDENT_NAME_1 (STUDENT_NR_1)
 * STUDENT_NAME_2 (STUDENT_NR_2)
 *
 * Grading:
 * Students who hand in clean code that fully satisfies the minimum requirements will get an 8. 
 * "Extra" steps can lead to higher marks because we want students to take the initiative. 
 * Extra steps can be, for example, in the form of measurements added to your code, a formal 
 * analysis of deadlock freeness etc.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <errno.h>          // for perror()
#include <pthread.h>

#include "uint128.h"
#include "flip.h"

// create a bitmask where bit at position n is set
#define BITMASK(n)          (((uint128_t) 1) << (n))

// check if bit n in v is set
#define BIT_IS_SET(v,n)     (((v) & BITMASK(n)) == BITMASK(n))

// set bit n in v
#define BIT_SET(v,n)        ((v) =  (v) |  BITMASK(n))

// clear bit n in v
#define BIT_CLEAR(v,n)      ((v) =  (v) & ~BITMASK(n))


static pthread_mutex_t      buffer_mutex          = PTHREAD_MUTEX_INITIALIZER;

static void * flip (void * arg);

int main (void)
{
	// TODO: start threads to flip the pieces and output the results
	// BIT SET = black
	// BIT CLEAR = white
	// (see thread_test() and thread_mutex_test() how to use threads and mutexes,
	//  see bit_test() how to manipulate bits in a large integer)

	for(int s = 0; s <= NROF_PIECES; s++) {
		BIT_SET(buffer[s/128],s%128);
	}

	int 		nrof_threads = 0;
	pthread_t   	thread_id[NROF_THREADS];
    
	for(int i = 2; i <= NROF_PIECES; i++) {

		while (nrof_threads >= NROF_THREADS) {
			pthread_join (thread_id[(i-2)%NROF_THREADS], NULL);
			nrof_threads--;
		}
		
		// New thread
		int *       parameter;

		// parameter to be handed over to the thread
		parameter = malloc (sizeof (int));  
		*parameter = i;    

		pthread_create (&thread_id[(i-2)%NROF_THREADS], NULL, flip, parameter);
		
		nrof_threads++;


	}

	for(int t = 0; t < nrof_threads && t <= NROF_PIECES - 2; t++) {
		pthread_join (thread_id[t], NULL);	
	}

	// Print
	for(int s = 1; s <= NROF_PIECES; s++) {
		if(BIT_IS_SET(buffer[s/128], s%128)) {
			printf("%d\n", s);
		}	
	}

    	return (0);
}

static void * flip (void * arg) {

	int *   argi; 
	int     i;      

	argi = (int *) arg;   
	i = *argi;              
	free (arg);

	for(int j = 1; i * j <= NROF_PIECES;j++) {
		pthread_mutex_lock (&buffer_mutex);
		if(BIT_IS_SET(buffer[(i*j)/128],(i*j)%128)) {
			BIT_CLEAR(buffer[(i*j)/128],(i*j)%128);
		}
		else {
			BIT_SET(buffer[(i*j)/128],(i*j)%128);
		}
		pthread_mutex_unlock (&buffer_mutex);
	}

	return (NULL);
	
}

